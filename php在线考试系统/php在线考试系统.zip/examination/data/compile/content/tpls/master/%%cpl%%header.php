<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>在线考试系统</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" type="text/css" href="app/core/styles/css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="app/core/styles/css/datetimepicker.css" />
	<link rel="stylesheet" type="text/css" href="app/core/styles/css/jquery-ui.min.css" />
	<link rel="stylesheet" type="text/css" href="app/core/styles/css/peskin.css" />
	<!--[if lt IE 9]>
	<script src="app/core/styles/js/html5shiv.min.js"></script>
	<script src="app/core/styles/js/respond.min.js"></script>
	<![endif]-->
	<script src="app/core/styles/js/jquery.min.js"></script>
	<script src="app/core/styles/js/jquery-ui.min.js"></script>
	<script src="app/core/styles/js/bootstrap.min.js"></script>
	<script src="app/core/styles/js/bootstrap-datetimepicker.js"></script>
	<script src="app/core/styles/js/all.fine-uploader.min.js"></script>
	<script src="app/core/styles/js/ckeditor/ckeditor.js"></script>
	<script src="app/core/styles/js/plugin.js"></script>
</head>