<footer class="container-fluid text-center" style="background-color:#337AB7;">
	<p style="padding:1rem;">
		在线考试 <br />
		Copyright © 2015-2017
	</p>
</footer>