<!--左侧-->
	<div class="con_left">
    	<ul class="con_nav">
        	<li class="tit"><span>栏目发布</span></li>
            <li<?php echo $quanxian; ?>><a href="type_list.php" class="lmtype_list">栏目中心</a></li>
            <li><a href="art_list.php" class="lmart_list">内容列表</a></li>
            <li><a href="type_list.php?fabu" class="type_list_fabu">发布</a></li>
        </ul>
    </div>