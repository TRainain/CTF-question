<?php
define('HOST', '127.0.0.1');//数据库地址
define('USERNAME', 'cms');//数据库用户名
define('PASSWORD', '7eceabe3506caaf1');//数据库密码
define('DBNAME', 'cms');//数据库名称
define('CHARSET', 'utf8');//编码
define('URL', 'aHR0cDovL2FwaS56aGFuYmFuZ3podS5jb20v');
?>