// 引入express模块，用于创建web服务器  
const express = require('express');   
// 引入body-parser模块，用于解析请求体中的JSON数据  
const bodyParser = require('body-parser');    
// 使用express创建应用实例  
const app = express();   
// 引入fs模块，用于文件操作  
const fs = require("fs");    
// 引入path模块，用于处理文件和目录的路径  
const path = require('path');    
// 引入vm模块，用于创建安全的沙箱环境执行代码  
const vm = require("vm");  

  
// 使用body-parser中间件解析JSON格式的请求体  
app.use(bodyParser.json());    
// 设置视图文件的目录  
app.set('views', path.join(__dirname, 'views'));    
// 设置静态文件的目录  
app.use(express.static(path.join(__dirname, '/public')));  


// 定义GET请求处理函数，当访问根路径'/'时执行  
app.get('/', function (req, res){  
    // 发送public目录下的home.html文件作为响应  
    res.sendFile(__dirname + '/public/home.html');  
});  


// 定义一个WAF函数，用于检测代码中是否包含敏感词汇  
function waf(code) {  
    // 定义正则表达式，匹配敏感词汇  
    let pattern = /(\[.*?\]|exec|spawn|Buffer|\\|\+|concat|eval|Function)/g;  
    // 如果代码匹配到敏感词汇  
    if(code.match(pattern)){  
        // 抛出错误，并给出提示信息  
        throw new Error("what can I say? hacker out!!");  
    }  
}  


// 定义POST请求处理函数，当向根路径'/'发送POST请求时执行  
app.post('/', function (req, res){  
    // 获取请求体中的code字段  
    let code = req.body.code;  
    // 创建一个空对象作为沙箱环境  
    let sandbox = Object.create(null);  
    // 创建vm上下文，并将sandbox对象作为上下文  
    let context = vm.createContext(sandbox);  
    try {  
        // 调用WAF函数检查代码  
        waf(code);  
        // 在沙箱环境中执行代码  
        let result = vm.runInContext(code, context);  
        // 在控制台打印执行结果  
        console.log(result);  
    } catch (e){  
        // 如果执行代码过程中发生错误  
        console.log(e.message);  
        // 尝试引入hack模块（注意：这是一个不安全的做法，应避免在生产环境中使用）  
        // require('./hack');  
    }  
});  

  
// 定义GET请求处理函数，当访问'/secret'路径时执行  
app.get('/secret', function (req, res){  
    // 判断当前文件的__filename属性是否为null  
    if(process.__filename == null) {  
        // 如果为null，读取当前文件内容  
        let content = fs.readFileSync(__filename, "utf-8");  
        // 将文件内容作为响应发送  
        return res.send(content);  
    } else {  
        // 如果不为null，读取process.__filename指向的文件内容  
        let content = fs.readFileSync(process.__filename, "utf-8");  
        // 将文件内容作为响应发送  
        return res.send(content);  
    }  
});  
  
// 监听3000端口，当服务器启动时，在控制台打印监听信息  
app.listen(3000, ()=>{  
    console.log("listen on 3000");  
});